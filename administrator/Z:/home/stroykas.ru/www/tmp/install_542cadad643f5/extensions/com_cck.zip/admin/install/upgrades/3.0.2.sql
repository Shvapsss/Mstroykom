
UPDATE `#__cck_core_fields` SET `storage_table` = "#__users", `storage_field` = "password2" WHERE `id` = 312;
