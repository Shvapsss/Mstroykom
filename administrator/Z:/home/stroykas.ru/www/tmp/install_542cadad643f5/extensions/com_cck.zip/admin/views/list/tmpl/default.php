<?php
/**
* @version 			SEBLOD 3.x Core ~ $Id: default.php sebastienheraud $
* @package			SEBLOD (App Builder & CCK) // SEBLOD nano (Form Builder)
* @url				http://www.seblod.com
* @editor			Octopoos - www.octopoos.com
* @copyright		Copyright (C) 2013 SEBLOD. All Rights Reserved.
* @license 			GNU General Public License version 2 or later; see _LICENSE.php
**/

defined( '_JEXEC' ) or die;

JText::script( 'COM_CCK_CONFIRM_DELETE' );
Helper_Include::addDependencies( $this->getName(), $this->getLayout() );
JHtml::_( 'stylesheet', 'media/cck/css/definitions/all.css', array(), false );
if ( ( JCck::getConfig_Param( 'validation', 2 ) > 1 ) && $this->config['validation'] != '' ) {
	Helper_Include::addValidation( $this->config['validation'], $this->config['validation_options'] );
	$js	=	'if (jQuery("#'.$this->config['formId'].'").validationEngine("validate",task) === true) { Joomla.submitform(((task=="save"||task=="list.save")?"search":task), document.getElementById("'.$this->config['formId'].'")); }';
} else {
	$js	=	'Joomla.submitform(((task=="save"||task=="list.save")?"search":task), document.getElementById("'.$this->config['formId'].'"));';
}
$app	=	JFactory::getApplication();
$css	=	'div.cck_forms.cck_search div.cck_label label{line-height:28px;} div.seblod.pagination{text-align:center;}'
		.	'form div.pagination div.button2-left,form div.pagination div.button2-right, form div.pagination div.limit{margin-right:10px!important;}'
		.	'div.cck_page_list div.pagination .total{float:right; line-height:24px;}';
JFactory::getDocument()->addStyleDeclaration( $css );
?>

<script type="text/javascript">
<?php echo $this->config['submit']; ?> = function(task) { <?php echo $js; ?> }
Joomla.submitbutton = function(task, cid)
{
	if (task == "<?php echo $this->vName; ?>.delete") {
		if (!confirm(Joomla.JText._('COM_CCK_CONFIRM_DELETE'))) {
			return false;
		}
	}
	jQuery("#adminForm").append('<input type="hidden" id="return" name="return" value="<?php echo base64_encode( JFactory::getURI() ); ?>">');
	Joomla.submitform(task);
}
</script>

<?php
if ( $this->show_list_desc == 1 && $this->description != '' ) {
	echo '<div class="cck_page_desc'.$this->pageclass_sfx.'">' . JHtml::_( 'content.prepare', $this->description ) . '</div><div class="clr"></div>';
}

echo ( $this->config['action'] ) ? $this->config['action'] : '<form action="'.JRoute::_( 'index.php?option='.$this->option.'&view='.$this->getName() ).'" autocomplete="off" method="get" id="'.$this->config['formId'].'" name="'.$this->config['formId'].'">';
echo '<div class="seblod first">' . $this->form . '</div>';
?>

<div class="cck_page_list<?php echo $this->pageclass_sfx; ?>" id="system">
	<?php
	if ( $this->show_pagination == -1 || $this->show_pagination == 1 ) {
		echo '<div class="'.$this->class_pagination.'">' . $this->pagination->getPagesLinks() . '</div>';
	}
	if ( @$this->search->content > 0 ) {
		echo '<div class="seblod">'.$this->data.'</div>';
	} else {
		echo $this->loadTemplate( 'items' );
	}
	if ( $this->show_pages_number || $this->show_pagination > -1 ) {
		$item_number	=	'';
		if ( $this->show_items_number ) {
			$label	=	$this->label_items_number;
			if ( $this->config['doTranslation'] ) {
				$label	=	JText::_( 'COM_CCK_' . str_replace( ' ', '_', trim( $label ) ) );
			}
			$item_number	=	'<div class="'.$this->class_items_number.'"><span>'.$this->total.'</span>&nbsp;'.$label.'</div>';
		}	
	    echo '<div class="seblod '.$this->class_pagination.'">';
		if ( $this->show_pagination > -1 ) {
			echo str_replace( '<div class="container">', '<div class="container">'.$item_number, $this->pagination->getListFooter() );
		}
	    echo '</div>';
	}
    ?>
</div>
<div class="clr"></div>
<div>
	<input type="hidden" name="boxchecked" value="0" />
	<input type="hidden" id="option" name="option" value="com_cck" />
	<input type="hidden" id="view" name="view" value="list" />
	<input type="hidden" name="search" value="<?php echo $this->search->name; ?>" />
	<input type="hidden" id="task" name="task" value="search" />
	<?php
	$tmpl	=	$app->input->get( 'tmpl', '' );
	if ( $tmpl ) { ?>
	<input type="hidden" name="tmpl" value="<?php echo $tmpl; ?>" />
	<?php } ?>
</div>
</form>
<?php
if ( $this->show_list_desc == 2 && $this->description != '' ) {
	echo '<div class="seblod cck_page_desc'.$this->pageclass_sfx.'">' . JHtml::_( 'content.prepare', $this->description ) . '</div><div class="clr"></div>';
}
Helper_Display::quickCopyright();
?>